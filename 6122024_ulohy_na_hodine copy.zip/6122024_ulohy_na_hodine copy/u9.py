def calc(num1, num2, operator):
    if operator == '+':
        return num1 + num2
    elif operator == '-':
        return num1 - num2
    elif operator == '*':
        return num1 * num2
    elif operator == '/':
        return num1 / num2 if num2 != 0 else "Nulou sa neda delit"
    else:
        return "Neplatný operátor"

print(calc(10, 3, "*"))