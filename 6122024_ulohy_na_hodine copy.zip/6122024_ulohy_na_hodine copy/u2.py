def c_to_f(c):
    return print(c * 9/5 + 32)

def f_to_c(f):
    return print((f - 32) * 5/9)

numc = int(input("Zadajte číslo v Celsius: "))
c_to_f(numc)
numf = int(input("Zadajte číslo vo Fahrenheitoch: "))
f_to_c(numf)
