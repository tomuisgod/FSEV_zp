def vowels(slovo):
    samohlasky = "aeiouyáéíóúýä"
    return ''.join('*' if p in samohlasky else p for p in slovo)

print(vowels("samohlasky"))