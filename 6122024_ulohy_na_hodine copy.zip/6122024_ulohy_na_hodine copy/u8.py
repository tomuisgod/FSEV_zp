def palindrom(text):
    text = ''.join(p.lower() for p in text if p.isalnum())
    return text == text[::-1]

print(palindrom("Anna"))