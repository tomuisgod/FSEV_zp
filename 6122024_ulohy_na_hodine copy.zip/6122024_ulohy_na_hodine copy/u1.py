def time(hodina):
    if 0 <= hodina < 12:
        return print("dobre rano")
    elif 12 <= hodina < 18:
        return print("dobry den")
    elif 18 <= hodina < 24:
        return print("dobry vecer")
    else:
        return print("bol zadany nespravny cas: zadajte cislo od 0 po 24")


c = int(input("Zadajte cas v hodinach (12, 6, 23): "))
time(c)
