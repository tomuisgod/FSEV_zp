def znak_counter(string, znak):
    return string.count(znak)

print(znak_counter("Neviem", "e"))