def caesarova_sifra(text, posun):
    zasifrovane = []
    for znak in text:
        if znak.isalpha():
            posunute = ord(znak.lower()) + posun
            if posunute > ord('z'):
                posunute -= 26
            novy_znak = chr(posunute)
            zasifrovane.append(novy_znak.upper() if znak.isupper() else novy_znak)
        else:
            zasifrovane.append(znak)
    return ''.join(zasifrovane)

print(caesarova_sifra("nemam rad rajciny", 3))