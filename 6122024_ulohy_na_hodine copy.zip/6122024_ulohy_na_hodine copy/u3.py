def over_heslo(heslo):
    if len(heslo) < 8:
        return False
    
    capital = any(p.isupper() for p in heslo)
    lower = any(p.islower() for p in heslo)
    num = any(p.isdigit() for p in heslo)

    return capital and lower and num

print(over_heslo("ProGraMoVanIe123"))