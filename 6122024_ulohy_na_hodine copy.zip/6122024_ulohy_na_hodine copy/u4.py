def fibonacci_postupnost(n):
    postupnost = [0, 1]
    while len(postupnost) < n:
        postupnost.append(postupnost[-1] + postupnost[-2])
    return postupnost[:n]

print(fibonacci_postupnost(4))